package com.android.tapas.umltraining;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class Home extends Fragment implements  View.OnClickListener
{
    Button btnOverview;
    Button btnProblemStatement;
    Button btnUseCase;
    Button btnClass;
    public Home() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_home, container, false);
        btnOverview=(Button)v.findViewById(R.id.btnOverview);
        btnOverview.setOnClickListener(this);
        btnProblemStatement=(Button)v.findViewById(R.id.btnProblemStatement);
        btnProblemStatement.setOnClickListener(this);
        btnUseCase=(Button)v.findViewById(R.id.btnUseCaseDiagram);
        btnUseCase.setOnClickListener(this);
        btnClass=(Button)v.findViewById(R.id.btnClassDiagram);
        btnClass.setOnClickListener(this);
        return  v;
    }

    //@Override
    public void onClick(View v)
    {
        FragmentManager manager = getFragmentManager();
        FragmentTransaction transaction =  manager.beginTransaction();
        Toast toast;
        switch (v.getId())
        {
            case R.id.btnOverview:
                toast = Toast.makeText(getActivity(), "Loading Introduction to UML...", Toast.LENGTH_SHORT);
                toast.show();
                IntroToUML introFragment = new IntroToUML();
                transaction.replace(R.id.fragment_container, introFragment,introFragment.getTag());
                transaction.addToBackStack(null);
                transaction.commit();

                break;
            case R.id.btnProblemStatement:
                toast = Toast.makeText(getActivity(), "Loading Problem Statement...", Toast.LENGTH_SHORT);
                toast.show();
                ProblemStatement probstmtFragment = new ProblemStatement();
                transaction.replace(R.id.fragment_container, probstmtFragment,probstmtFragment.getTag());
                transaction.addToBackStack(null);
                transaction.commit();
                break;
            case R.id.btnUseCaseDiagram:
                toast = Toast.makeText(getActivity(), "Loading Use case diagram...", Toast.LENGTH_SHORT);
                toast.show();
                DiagramUsecase useCaseFragment = new DiagramUsecase();
                transaction.replace(R.id.fragment_container, useCaseFragment,useCaseFragment.getTag());
                transaction.addToBackStack(null);
                transaction.commit();
                break;
            case R.id.btnClassDiagram:
                toast = Toast.makeText(getActivity(), "Loading Class Diagram...", Toast.LENGTH_SHORT);
                toast.show();
                DiagramClass classFragment = new DiagramClass();
                transaction.replace(R.id.fragment_container, classFragment,classFragment.getTag());
                transaction.addToBackStack(null);
                transaction.commit();
                break;
        }
    }


}
